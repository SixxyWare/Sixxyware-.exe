#pragma once

extern bool node_client();