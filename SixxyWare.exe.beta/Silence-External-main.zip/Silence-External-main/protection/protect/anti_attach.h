#pragma once

extern void AntiAttach();
