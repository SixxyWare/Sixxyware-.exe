#pragma once

extern int selfcode();