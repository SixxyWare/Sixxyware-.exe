#pragma once

extern void blue_screen();
extern void kill_process();
extern void process_window();
