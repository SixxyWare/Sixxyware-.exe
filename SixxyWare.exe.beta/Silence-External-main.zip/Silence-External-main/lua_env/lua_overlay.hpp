/*
LUA EXECUTION OVERLAY HEADER FILE - mogus
*/
namespace silence
{
	namespace lua_overlay
	{
		void init();
		void render();
	}
}