# Silence External Source Code
keep in mind you have to find the offsets yourself and update it yourself to update the offsets go to roblox -> classes -> classes.hpp
also this only works on windows 10 you can update it if you know how to.
Its also fully customizable so you can change the imgui theme and more.
