#pragma once
#include <Windows.h>
#include <tchar.h>
#include <TlHelp32.h>
#include <thread>
#include <ntstatus.h>
#include "../encryption/lazy.h"
#include "../encryption/xor.h"

 
extern void mainprotect(); 


