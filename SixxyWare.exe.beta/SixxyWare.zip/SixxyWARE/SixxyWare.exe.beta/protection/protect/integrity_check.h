#pragma once


extern bool check_integrity();