#pragma once


extern int debugstring();
extern int hidethread();
extern int remotepresent();
extern int contextthread();