#pragma once


extern void anti_dump();
