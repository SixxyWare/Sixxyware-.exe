#pragma once

#include <Windows.h>

namespace remap {
void RemapSelfImage(const PVOID RegionBase);

} 